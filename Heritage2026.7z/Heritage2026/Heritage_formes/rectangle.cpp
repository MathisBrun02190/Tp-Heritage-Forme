///////////////////////////////////////////////////////////
//  rectangle.cpp
//  Implementation of the Class CRetangle
//  Created on:      20-janv.-2026 10:20:43
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "rectangle.h"


CRectangle::CRectangle(){

}



/**
 * constructeur prends le param�tre "nom" de la classe de base et les deux
 * param�tres "longueur" et "largeur" propres � la classe CRectangle
 */
CRectangle::CRectangle(string nom, int _largeur, int _longueur) {

}


CRectangle::~CRectangle(){

}


/**
 * affiche le nom, la longueur, la largeur et la surface du rectangle
 */
void CRectangle::afficher(){

}



/**
 * retourne la surface du rectangle
 */
double CRectangle::surface(){

	return 0;
}