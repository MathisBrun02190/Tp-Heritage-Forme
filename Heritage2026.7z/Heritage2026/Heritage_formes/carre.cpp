///////////////////////////////////////////////////////////
//  carre.cpp
//  Implementation of the Class CCarre
//  Created on:      20-janv.-2026 10:11:05
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "carre.h"


CCarre::CCarre(){

}



CCarre::~CCarre(){

}


CCarre::CCarre(int _cote){

}


void CCarre::afficher(){

}

double CCarre::surface(){

	return 0;
}