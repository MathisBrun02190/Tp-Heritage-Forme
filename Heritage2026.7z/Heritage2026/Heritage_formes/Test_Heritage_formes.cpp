// Heritage_formes.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//

#include <iostream>

// fonctions de test à coder
void partie1();
void partie2();
/// etc...

int main()
{
    std::cout << "Test des classes formes\n";
}

