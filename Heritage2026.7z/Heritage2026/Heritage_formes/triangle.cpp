///////////////////////////////////////////////////////////
//  triangle.cpp
//  Implementation of the Class CTriangle
//  Created on:      20-janv.-2026 10:08:10
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "triangle.h"


CTriangle::CTriangle(){

}



CTriangle::~CTriangle(){

}


CTriangle::CTriangle(string nom, int _hauteur, int _base){

}


void CTriangle::afficher(){

}


double CTriangle::surface(){

	return 0;
}